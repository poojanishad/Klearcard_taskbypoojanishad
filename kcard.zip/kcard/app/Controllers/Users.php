<?php

namespace App\Controllers;

use \App\Libraries\OAuth;
use \OAuth2\Request;
use CodeIgniter\API\ResponseTrait;

use App\Models\UsersModel;

class Users extends BaseController
{

use ResponseTrait;

public function register()
{
	helper('form');
	$data = [];

	if($this->request->getMethod() != 'post')
		return $this->fail('Only post request is allowed');

	$rules = [
		'name' => 'required|min_length[3]|max_length[20]',
		'mobile' => 'required|is_unique[users.mobile]',
		'email' => 'required|valid_email|is_unique[users.email]',
		'card' => 'required',
		'password' => 'required'
	];

	if(! $this->validate($rules)){
		return $this->fail($this->validator->getErrors());
	}else{
		$model = new UsersModel();

		$mobile = $this->request->getVar('mobile');
		$email = $this->request->getVar('email');
		$card = $this->request->getVar('card');

		$data = [
			'name' => $this->request->getVar('name'),
			'mobile' => preg_replace('/\B[^@.]/', '*', $mobile),
			'email' => preg_replace('/\B[^@.]/', '*', $email),
			'card' => substr_replace($card, str_repeat('X', 12), 0, 12),
			'password' => $this->request->getVar('password')
		];

		$user_id = $model->insert($data);
		$update['id'] = $user_id;
		//$update['userid'] = 'KC'.$user_id;
		$update['userid'] = uniqid();
		$model->save($update);
		unset($update['id']);
		return $this->respondCreated($update);
	}

}

public function login()
{
	$oauth = new OAuth();
	$request = new Request();
	$respond = $oauth->server->handleTokenRequest($request->createFromGlobals());
	$code = $respond->getStatusCode();
	$body = $respond->getResponseBody();

	return $this->respond(json_decode($body), $code);

}


}
