<?php namespace APP\Libraries;

//use \OAuth2\Storage\Pdo;
use \App\Libraries\CustomOAuthStorage;

class OAuth{
	var $server;

	function __construct(){
		$this->init();
	}

	public function init(){
		$dsn = getenv('database.default.DSN');
		$username = getenv('database.default.username');
		$password = getenv('database.default.password');

		$config = array(
		    'access_lifetime' => 300
		);
		$storage = new CustomOAuthStorage(['dsn'=> $dsn,'username'=>$username,'password'=>$password]);
		$this->server = new \OAuth2\Server($storage,$config);
		$this->server->addGrantType(new \OAuth2\GrantType\UserCredentials($storage));
	}
}